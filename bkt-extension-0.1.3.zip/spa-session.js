(() => {
  // extension/src/auth/session.ts
  function extractSupabaseSession() {
    try {
      const storage = globalThis.localStorage;
      if (!storage) return null;
      let authKey = null;
      for (let i = 0; i < storage.length; i++) {
        const k = storage.key(i);
        if (k && /^sb-.+-auth-token$/.test(k)) {
          authKey = k;
          break;
        }
      }
      if (!authKey) return null;
      const refMatch = authKey.match(/^sb-(.+)-auth-token$/);
      const ref = refMatch ? refMatch[1] : "";
      const raw = storage.getItem(authKey);
      if (!raw) return null;
      let parsed;
      try {
        parsed = JSON.parse(raw);
      } catch {
        return null;
      }
      if (!parsed || typeof parsed !== "object") return null;
      const root = parsed;
      const session = "currentSession" in root && root.currentSession && typeof root.currentSession === "object" ? root.currentSession : root;
      const accessToken = typeof session.access_token === "string" ? session.access_token : "";
      if (!accessToken) return null;
      const user = session.user;
      return {
        ref,
        url: ref ? `https://${ref}.supabase.co` : "",
        accessToken,
        refreshToken: typeof session.refresh_token === "string" ? session.refresh_token : null,
        expiresAt: typeof session.expires_at === "number" ? session.expires_at : null,
        userId: user && typeof user.id === "string" ? user.id : null
      };
    } catch {
      return null;
    }
  }

  // extension/src/messages.ts
  var MSG = {
    /** SPA reader → background: the user's session (or null when signed out). */
    SESSION_PUSH: "BKT_SESSION_PUSH",
    /** ATS content → background: is the user signed in? */
    AUTH_STATUS: "BKT_AUTH_STATUS",
    /** ATS content → background: score this scraped JD via score-job-fit. */
    SCORE: "BKT_SCORE",
    /** ATS content → background: the contact profile for autofill. */
    PROFILE: "BKT_PROFILE",
    /** ATS content → background: the prepared-application payload for this page. */
    PREPARED: "BKT_PREPARED"
  };

  // extension/src/content/spa-session.ts
  function relay() {
    const session = extractSupabaseSession();
    void chrome.runtime.sendMessage({ type: MSG.SESSION_PUSH, session }).catch(() => void 0);
  }
  relay();
  window.addEventListener("focus", relay);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") relay();
  });
})();
