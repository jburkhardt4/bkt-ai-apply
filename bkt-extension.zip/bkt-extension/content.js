(() => {
  // .claude/worktrees/prepare-application-wiring/extension/src/configs/fieldSignals.ts
  var DEFAULT_FIELD_LABELS = {
    first_name: ["first name", "given name", "legal first name"],
    last_name: ["last name", "family name", "surname", "legal last name"],
    preferred_name: ["preferred name", "preferred first name", "nickname"],
    email: ["email", "e-mail"],
    phone: ["phone", "mobile", "telephone"],
    linkedin: ["linkedin"],
    website: ["website", "portfolio", "personal site", "personal website"],
    location: ["location", "current city"],
    state: ["state", "which state", "state you", "reside", "province"],
    country: ["country"]
  };
  var SENSITIVE_KEYS = /* @__PURE__ */ new Set([
    "work_auth",
    "requires_sponsorship",
    "requires_sponsorship_future",
    "security_clearance",
    "desired_salary",
    "eeo_gender",
    "eeo_race",
    "eeo_hispanic_latino",
    "eeo_veteran",
    "eeo_disability"
  ]);
  function applySignals(fields) {
    return fields.map((f) => ({
      ...f,
      labels: f.labels ?? (f.key.startsWith("answer:") ? void 0 : DEFAULT_FIELD_LABELS[f.key]),
      sensitive: f.sensitive ?? SENSITIVE_KEYS.has(f.key)
    }));
  }

  // .claude/worktrees/prepare-application-wiring/extension/src/configs/greenhouse.ts
  var greenhouseConfig = {
    ats: "greenhouse",
    version: "2026-06-19",
    match: { hosts: ["boards.greenhouse.io", "job-boards.greenhouse.io"] },
    jd: { container: "#content, .job__description", title: "h1.app-title" },
    // applySignals() enriches each field with default <label> synonyms + the
    // sensitive flag (configs/fieldSignals.ts), powering the B5 label-text fallback
    // used when Greenhouse's opaque `#question_<id>` selectors miss. EEO / work-auth
    // / sponsorship are flagged sensitive → never fuzzy-matched (BR-156); only their
    // direct selectors below ever apply.
    fields: applySignals([
      { key: "first_name", selector: "#first_name", type: "text" },
      { key: "last_name", selector: "#last_name", type: "text" },
      // Greenhouse has no dedicated preferred-name input on the standard form; some
      // postings add it as a custom question. LIVE-TUNE per posting.
      {
        key: "preferred_name",
        selector: '#preferred_name, input[name*="preferred"]',
        type: "text"
      },
      { key: "email", selector: "#email", type: "email" },
      { key: "phone", selector: "#phone", type: "tel" },
      // Phone country-code widget. Greenhouse renders an intl-tel-input style
      // country selector adjacent to the phone field on postings that collect it;
      // it is a react-select on the newer template and a native <select> on some.
      // We map it as react-select (the macro's pickOption tolerates a missing
      // control via report.missing). LIVE-TUNE — the container id varies per
      // posting; leave the human to set it if the selector does not resolve.
      {
        key: "phone_country",
        selector: '#phone_country_control, [id*="phone_country"] .select__control, [class*="country"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      // NOTE: employment_history is intentionally NOT mapped. Greenhouse's standard
      // application form has no stable flat inputs for prior employment (it is
      // resume-driven; some postings add bespoke custom questions with hashed
      // names). Inventing selectors here would risk filling the wrong field
      // (UAT-4). The prepared-application path surfaces employment_history as a
      // review-gated block for the human instead — see preparedFill.ts.
      {
        key: "linkedin",
        selector: 'input[name*="urls"][name*="LinkedIn"], input[name*="linkedin"]',
        type: "url"
      },
      // Website / portfolio custom-URL question (Greenhouse stores these under
      // job_application[urls][...]). LIVE-TUNE — the URL label varies per posting.
      {
        key: "website",
        selector: 'input[name*="urls"][name*="Website"], input[name*="urls"][name*="Portfolio"], input[name*="website"]',
        type: "url"
      },
      // Greenhouse's standard form has a single "Location (City)" autocomplete on
      // some postings; it is a plain text input on others. LIVE-TUNE.
      {
        key: "location",
        selector: '#job_application_location, input[name*="location"], #location',
        type: "text"
      },
      // State of residence — react-select on the job-boards template ("In which
      // state do you currently reside?"). The control id is opaque (`question_<id>`),
      // so the direct selector is best-effort; the B5 matcher resolves it by the
      // `state` label synonyms. Value comes from candidate_profiles.state.
      {
        key: "state",
        selector: '#state_control, [id*="state"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      // Country — react-select ("Country"). Locator-ready via the `country` label;
      // its value is pending the new candidate_profiles.location_country column
      // (Part B3), so today it reports no_value rather than filling.
      {
        key: "country",
        selector: '#country_control, [id*="country"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      { key: "resume", selector: 'input[type="file"][name*="resume"]', type: "file" },
      { key: "cover_letter", selector: 'input[type="file"][name*="cover_letter"]', type: "file" },
      {
        key: "work_auth",
        selector: '#work_auth_control, [id*="work_authorization"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      // Sponsorship-now/future question — react-select. LIVE-TUNE (label varies:
      // "Will you now or in the future require sponsorship…").
      {
        key: "requires_sponsorship",
        selector: '#sponsorship_control, [id*="sponsorship"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      // --- EEO / voluntary self-identification (react-selects) ------------------
      // Greenhouse renders these in a demographic section near the bottom of the
      // form. Control ids are stable on the standard template; LIVE-TUNE if a
      // posting hashes them.
      {
        key: "eeo_gender",
        selector: '#gender_control, [id*="gender"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_race",
        selector: '#race_control, [id*="race"] .select__control, [id*="ethnicity"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_hispanic_latino",
        selector: '#hispanic_ethnicity_control, [id*="hispanic"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_veteran",
        selector: '#veteran_status_control, [id*="veteran"] .select__control',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_disability",
        selector: '#disability_status_control, [id*="disability"] .select__control',
        type: "react-select",
        strategy: "react-select"
      }
    ]),
    submit: { selector: 'button[type="submit"], #submit_app', autoClick: false }
  };

  // .claude/worktrees/prepare-application-wiring/extension/src/configs/lever.ts
  var leverConfig = {
    ats: "lever",
    version: "2026-06-19",
    match: { hosts: ["jobs.lever.co"] },
    jd: { container: ".posting-description, .content", title: ".posting-headline h2" },
    // applySignals() adds default <label> synonyms + the sensitive flag
    // (configs/fieldSignals.ts) so the B5 label-text fallback fires when Lever's
    // posting-specific `cards[...]`/`urls[...]` names miss; EEO fields stay
    // sensitive → never fuzzy-matched (BR-156).
    fields: applySignals([
      { key: "full_name", selector: 'input[name="name"]', type: "text" },
      { key: "email", selector: 'input[name="email"]', type: "email" },
      { key: "phone", selector: 'input[name="phone"]', type: "tel" },
      { key: "linkedin", selector: 'input[name="urls[LinkedIn]"], input[name*="LinkedIn"]', type: "url" },
      // Lever's "Current location" field (standard on most postings).
      {
        key: "location",
        selector: 'input[name="location"], input[name*="location"]',
        type: "text"
      },
      // Portfolio / personal-site URL question. LIVE-TUNE (label varies).
      {
        key: "website",
        selector: 'input[name="urls[Portfolio]"], input[name="urls[Website]"], input[name*="Portfolio"], input[name*="Website"]',
        type: "url"
      },
      { key: "resume", selector: 'input[type="file"][name="resume"]', type: "file" },
      // --- EEO / demographic (Lever uses native <select name="eeo[...]">) --------
      { key: "eeo_gender", selector: 'select[name="eeo[gender]"], select[name*="gender"]', type: "select" },
      {
        key: "eeo_race",
        selector: 'select[name="eeo[race]"], select[name*="race"], select[name*="ethnicity"]',
        type: "select"
      },
      {
        key: "eeo_veteran",
        selector: 'select[name="eeo[veteran]"], select[name*="veteran"]',
        type: "select"
      },
      {
        key: "eeo_disability",
        selector: 'select[name="eeo[disability]"], select[name*="disability"]',
        type: "select"
      }
    ]),
    submit: { selector: 'button[type="submit"], .template-btn-submit', autoClick: false }
  };

  // .claude/worktrees/prepare-application-wiring/extension/src/configs/ashby.ts
  var ashbyConfig = {
    ats: "ashby",
    version: "2026-06-19",
    match: { hosts: ["jobs.ashbyhq.com", "ashbyhq.com"] },
    jd: { container: '[class*="description"], ._description', title: "h1" },
    // applySignals() enriches each field with default <label> synonyms + the
    // sensitive flag (configs/fieldSignals.ts) so the B5 label-text fallback fires
    // when Ashby's hashed react-select / custom-question selectors miss. Sensitive
    // fields (work-auth / sponsorship / EEO) are never fuzzy-matched (BR-156).
    fields: applySignals([
      { key: "full_name", selector: 'input[name="_systemfield_name"], input[aria-label="Name"]', type: "text" },
      // Split-name fields — some AshbyQ forms render separate first/last inputs
      // instead of the combined "Name" field above. Non-sensitive identity (not
      // EEO/eligibility), so safe to fill. Best-effort selectors. LIVE-TUNE.
      { key: "first_name", selector: 'input[autocomplete="given-name"], input[name*="first" i], input[aria-label*="First" i]', type: "text" },
      { key: "last_name", selector: 'input[autocomplete="family-name"], input[name*="last" i], input[aria-label*="Last" i]', type: "text" },
      // Preferred name — custom question on many Ashby forms. LIVE-TUNE.
      {
        key: "preferred_name",
        selector: 'input[aria-label*="Preferred"], input[name*="preferred"]',
        type: "text"
      },
      { key: "email", selector: 'input[name="_systemfield_email"], input[type="email"]', type: "email" },
      // Ashby phone is a native input plus a country react-select on some forms.
      { key: "phone", selector: 'input[name="_systemfield_phone"], input[autocomplete="tel"], input[type="tel"]', type: "tel" },
      { key: "linkedin", selector: 'input[aria-label*="LinkedIn" i], input[name*="linkedin" i], input[placeholder*="linkedin" i]', type: "url" },
      // Website / portfolio — custom URL question. LIVE-TUNE.
      {
        key: "website",
        selector: 'input[aria-label*="Website" i], input[aria-label*="Portfolio" i], input[name*="website" i], input[autocomplete="url"]',
        type: "url"
      },
      // Location — Ashby uses a location autocomplete; plain text on simpler forms. LIVE-TUNE.
      {
        key: "location",
        selector: 'input[aria-label*="Location" i], input[name*="_systemfield_location" i], input[name*="location" i], input[autocomplete="address-level2"]',
        type: "text"
      },
      {
        key: "work_auth",
        selector: "#ashby_work_auth_control",
        type: "react-select",
        strategy: "react-select"
      },
      // Sponsorship react-select. LIVE-TUNE (Ashby hashes the container id).
      {
        key: "requires_sponsorship",
        selector: '#ashby_sponsorship_control, [aria-label*="sponsorship"]',
        type: "react-select",
        strategy: "react-select"
      },
      // --- EEO / demographic (Ashby react-selects; ids hashed → LIVE-TUNE) ------
      {
        key: "eeo_gender",
        selector: '#ashby_gender_control, [aria-label*="Gender"]',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_race",
        selector: '#ashby_race_control, [aria-label*="Race"], [aria-label*="Ethnicity"]',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_veteran",
        selector: '#ashby_veteran_control, [aria-label*="Veteran"]',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_disability",
        selector: '#ashby_disability_control, [aria-label*="Disability"]',
        type: "react-select",
        strategy: "react-select"
      },
      { key: "resume", selector: 'input[type="file"]', type: "file" }
    ]),
    submit: { selector: 'button[type="submit"]', autoClick: false }
  };

  // .claude/worktrees/prepare-application-wiring/extension/src/configs/workday.ts
  var workdayConfig = {
    ats: "workday",
    version: "2026-06-19",
    match: { hosts: ["myworkdayjobs.com", "workday.com"] },
    // UNCERTAIN: the JD lives on the posting page (before the wizard). These target
    // the common job-details automation ids; LIVE-TUNE.
    jd: {
      container: '[data-automation-id="jobPostingDescription"], [data-automation-id="job-details"]',
      title: '[data-automation-id="jobPostingHeader"], h1'
    },
    fields: [
      // --- My Information: legal name (UNCERTAIN — tenant-customized) -----------
      { key: "first_name", selector: '[data-automation-id="legalNameSection_firstName"]', type: "text" },
      { key: "last_name", selector: '[data-automation-id="legalNameSection_lastName"]', type: "text" },
      // Preferred name lives behind a "I have a preferred name" checkbox on some
      // tenants → the input may not be present until toggled. UNCERTAIN.
      {
        key: "preferred_name",
        selector: '[data-automation-id="preferredNameSection_firstName"]',
        type: "text"
      },
      // --- Contact (UNCERTAIN) --------------------------------------------------
      { key: "email", selector: '[data-automation-id="email"], input[type="email"]', type: "email" },
      {
        key: "phone",
        selector: '[data-automation-id="phone-number"], [data-automation-id="phoneNumber"]',
        type: "tel"
      },
      // Country phone code + phone device type are custom listbox widgets. UNCERTAIN.
      {
        key: "phone_country",
        selector: '[data-automation-id="countryPhoneCode"] button, [data-automation-id="country-phone-code"]',
        type: "react-select",
        strategy: "react-select"
      },
      // --- Address (UNCERTAIN) --------------------------------------------------
      {
        key: "location",
        selector: '[data-automation-id="addressSection_city"]',
        type: "text"
      },
      // State/region is a custom listbox on US tenants. UNCERTAIN.
      {
        key: "state",
        selector: '[data-automation-id="addressSection_countryRegion"] button, [data-automation-id="countryRegion"] button',
        type: "react-select",
        strategy: "react-select"
      },
      // --- My Experience: links + resume (UNCERTAIN) ----------------------------
      {
        key: "linkedin",
        selector: '[data-automation-id="linkedinQuestion"], input[aria-label*="LinkedIn"]',
        type: "url"
      },
      {
        key: "website",
        selector: '[data-automation-id="websiteQuestion"], input[aria-label*="Website"]',
        type: "url"
      },
      // Resume → file input; macro flags manual_required (the human attaches it).
      {
        key: "resume",
        selector: '[data-automation-id="file-upload-input-ref"], input[type="file"]',
        type: "file"
      },
      // --- Application Questions: work auth + sponsorship (custom listboxes) ----
      // UNCERTAIN — these are tenant-authored questions; the automation ids below
      // are common but not guaranteed. They are listbox widgets → react-select fit.
      {
        key: "work_auth",
        selector: '[data-automation-id="workAuthorization"] button, [aria-label*="authorized to work"]',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "requires_sponsorship",
        selector: '[data-automation-id="sponsorship"] button, [aria-label*="sponsorship"]',
        type: "react-select",
        strategy: "react-select"
      },
      // --- Voluntary Disclosures / Self-Identify: EEO (custom listboxes) --------
      // UNCERTAIN — Workday splits these across the Voluntary Disclosures and
      // Self-Identify steps; automation ids vary by tenant + region.
      {
        key: "eeo_gender",
        selector: '[data-automation-id="gender"] button, [aria-label*="Gender"]',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_race",
        selector: '[data-automation-id="ethnicity"] button, [data-automation-id="race"] button, [aria-label*="Race"]',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_hispanic_latino",
        selector: '[data-automation-id="hispanicOrLatino"] button, [aria-label*="Hispanic"]',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_veteran",
        selector: '[data-automation-id="veteranStatus"] button, [aria-label*="Veteran"]',
        type: "react-select",
        strategy: "react-select"
      },
      {
        key: "eeo_disability",
        selector: '[data-automation-id="disabilityStatus"] button, [aria-label*="Disability"]',
        type: "react-select",
        strategy: "react-select"
      }
    ],
    // UNCERTAIN: Workday's advance control is a per-step "Continue"/"Submit"
    // button, NOT a single form submit. autoClick stays false (BR-151) — the
    // human advances + submits every step.
    submit: {
      selector: '[data-automation-id="pageFooterNextButton"], [data-automation-id="bottom-navigation-next-button"], button[type="submit"]',
      autoClick: false
    }
  };

  // .claude/worktrees/prepare-application-wiring/extension/src/configs/index.ts
  var BOARD_CONFIGS = [greenhouseConfig, leverConfig, ashbyConfig, workdayConfig];
  function resolveBoardConfig(host, configs = BOARD_CONFIGS) {
    const h = host.trim().toLowerCase();
    if (!h) return null;
    for (const cfg of configs) {
      for (const pattern of cfg.match.hosts) {
        const p = pattern.toLowerCase();
        if (h === p || h.endsWith(`.${p}`)) return cfg;
      }
    }
    return null;
  }

  // .claude/worktrees/prepare-application-wiring/extension/src/autofill.ts
  async function applyAutofill(input) {
    const { config, payload } = input;
    const report = { filled: [], missing: [], skipped: [] };
    const setNativeValue = (el, value) => {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    };
    const waitFor = async (predicate, timeoutMs = 600, stepMs = 25) => {
      const start = Date.now();
      for (; ; ) {
        const hit = predicate();
        if (hit) return hit;
        if (Date.now() - start >= timeoutMs) return null;
        await new Promise((res) => setTimeout(res, stepMs));
      }
    };
    const pickOption = (opts, wanted) => {
      const norm = (o) => (o.textContent ?? "").trim().toLowerCase();
      const exact = opts.filter((o) => norm(o) === wanted);
      if (exact.length) return exact[0];
      const prefix = opts.filter((o) => {
        const t = norm(o);
        return t !== "" && (t.startsWith(wanted) || wanted.startsWith(t));
      });
      if (prefix.length === 1) return prefix[0];
      const contains = opts.filter((o) => norm(o).includes(wanted));
      if (contains.length === 1) return contains[0];
      return null;
    };
    const fillReactSelect = async (control, value) => {
      control.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      control.click();
      const wanted = value.trim().toLowerCase();
      const option = await waitFor(() => {
        const opts = Array.from(document.querySelectorAll('[role="option"]'));
        return opts.length ? pickOption(opts, wanted) : null;
      });
      if (!option) return false;
      option.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      option.click();
      return true;
    };
    const normText = (s) => s.replace(/\s+/g, " ").trim().toLowerCase();
    const SELECT_CTRL = '[class*="select__control"], .rs-control, [role="combobox"]';
    const isSelect = (f) => f.type === "react-select" || f.type === "select" || f.strategy === "react-select";
    const controlFromLabel = (label, field) => {
      let target = null;
      const forId = label.getAttribute("for");
      if (forId) target = document.getElementById(forId);
      if (!target) target = label.querySelector(`${SELECT_CTRL}, input, textarea, select`);
      if (!target && label.parentElement) {
        target = label.parentElement.querySelector(`${SELECT_CTRL}, input, textarea, select`);
      }
      if (!target) return null;
      if (isSelect(field)) {
        if (target.matches(SELECT_CTRL)) return target;
        const within = target.querySelector(SELECT_CTRL);
        if (within) return within;
        const up = target.closest(SELECT_CTRL);
        if (up) return up;
        const container = target.closest('[class*="select__"]');
        return container?.querySelector(SELECT_CTRL) ?? null;
      }
      if (target instanceof HTMLInputElement) {
        return target.type === "file" || target.type === "hidden" ? null : target;
      }
      return target instanceof HTMLTextAreaElement ? target : null;
    };
    const locateTextByAttrs = (wants) => {
      const inputs = Array.from(document.querySelectorAll("input, textarea")).filter(
        (el) => el instanceof HTMLInputElement ? el.type !== "file" && el.type !== "hidden" : true
      );
      const hits = inputs.filter((el) => {
        const hay = normText(
          [
            el.getAttribute("autocomplete"),
            el.getAttribute("name"),
            el.id,
            el.getAttribute("aria-label"),
            el.getAttribute("placeholder")
          ].filter(Boolean).join(" ")
        );
        return hay !== "" && wants.some((w) => hay.includes(w));
      });
      return hits.length === 1 ? hits[0] : null;
    };
    const locateByLabel = (field) => {
      const wants = (field.labels ?? []).map(normText).filter(Boolean);
      if (!wants.length) return null;
      const labels = Array.from(document.querySelectorAll("label, legend"));
      let matches = labels.filter((l) => {
        const t = normText(l.textContent ?? "");
        return t !== "" && wants.some((w) => t.includes(w));
      });
      if (matches.length > 1) {
        const exact = matches.filter((l) => wants.includes(normText(l.textContent ?? "")));
        if (exact.length !== 1) return isSelect(field) ? null : locateTextByAttrs(wants);
        matches = exact;
      }
      if (matches.length === 1) {
        const ctrl = controlFromLabel(matches[0], field);
        if (ctrl) return ctrl;
      }
      return isSelect(field) ? null : locateTextByAttrs(wants);
    };
    for (const field of config.fields) {
      let el = document.querySelector(field.selector);
      if (!el && !field.sensitive && field.labels?.length) {
        el = locateByLabel(field);
      }
      if (!el) {
        report.missing.push(field.key);
        continue;
      }
      if (field.type === "file") {
        report.skipped.push({ key: field.key, reason: "manual_required" });
        continue;
      }
      const value = payload[field.key];
      if (field.type === "react-select" || field.strategy === "react-select") {
        if (value === void 0 || value === "") {
          report.skipped.push({ key: field.key, reason: "no_value" });
          continue;
        }
        const ok = await fillReactSelect(el, value);
        if (ok) report.filled.push(field.key);
        else report.skipped.push({ key: field.key, reason: "needs_strategy" });
        continue;
      }
      if (value === void 0 || value === "") {
        report.skipped.push({ key: field.key, reason: "no_value" });
        continue;
      }
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        setNativeValue(el, value);
        el.setAttribute("data-bkt-filled", "1");
        report.filled.push(field.key);
      } else if (el instanceof HTMLSelectElement) {
        el.value = value;
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.setAttribute("data-bkt-filled", "1");
        report.filled.push(field.key);
      } else {
        report.skipped.push({ key: field.key, reason: "needs_strategy" });
      }
    }
    return report;
  }

  // .claude/worktrees/prepare-application-wiring/extension/src/matchScorePanel.ts
  function renderMatchScorePanel(data) {
    const PANEL_ID = "bkt-fit-panel";
    document.getElementById(PANEL_ID)?.remove();
    const label = data.score >= 80 ? "Strong fit" : data.score >= 65 ? "Possible fit" : "Weak fit";
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.setAttribute("data-bkt", "fit-panel");
    panel.setAttribute("role", "complementary");
    const heading = document.createElement("div");
    heading.setAttribute("data-bkt", "score");
    heading.textContent = `${data.score}/100 \xB7 ${label}${data.estimated ? " (estimated)" : ""}`;
    panel.appendChild(heading);
    if (data.recommendation) {
      const rec = document.createElement("div");
      rec.setAttribute("data-bkt", "recommendation");
      rec.textContent = `Recommendation: ${data.recommendation}`;
      panel.appendChild(rec);
    }
    const addList = (title, items, kind) => {
      const section = document.createElement("div");
      section.setAttribute("data-bkt", kind);
      const h = document.createElement("div");
      h.textContent = title;
      section.appendChild(h);
      const ul = document.createElement("ul");
      for (const item of items) {
        const li = document.createElement("li");
        li.textContent = item;
        ul.appendChild(li);
      }
      section.appendChild(ul);
      panel.appendChild(section);
    };
    addList("Matched skills", data.matched, "matched");
    addList("Missing keywords", data.missing, "missing");
    document.body.appendChild(panel);
  }

  // .claude/worktrees/prepare-application-wiring/extension/src/payload.ts
  function splitName(full) {
    const parts = full.trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) return { first: "", last: "" };
    return { first: parts[0], last: parts.slice(1).join(" ") };
  }
  function buildPayload(profile) {
    const payload = {};
    const first = profile.firstName ?? (profile.fullName ? splitName(profile.fullName).first : "");
    const last = profile.lastName ?? (profile.fullName ? splitName(profile.fullName).last : "");
    const full = profile.fullName?.trim() ?? [first, last].filter(Boolean).join(" ");
    if (full) payload["full_name"] = full;
    if (first) payload["first_name"] = first;
    if (last) payload["last_name"] = last;
    if (profile.preferredName) payload["preferred_name"] = profile.preferredName;
    if (profile.email) payload["email"] = profile.email;
    if (profile.phone) payload["phone"] = profile.phone;
    if (profile.phoneCountry) payload["phone_country"] = profile.phoneCountry;
    if (profile.linkedin) payload["linkedin"] = profile.linkedin;
    if (profile.website) payload["website"] = profile.website;
    if (profile.location) payload["location"] = profile.location;
    if (profile.state) payload["state"] = profile.state;
    if (profile.workAuthorization) payload["work_auth"] = profile.workAuthorization;
    if (typeof profile.requiresSponsorship === "boolean") {
      payload["requires_sponsorship"] = profile.requiresSponsorship ? "Yes" : "No";
    }
    const eeo = profile.eeo ?? {};
    const eeoMap = {
      gender: "eeo_gender",
      race_ethnicity: "eeo_race",
      hispanic_latino: "eeo_hispanic_latino",
      veteran_status: "eeo_veteran",
      disability_status: "eeo_disability"
    };
    for (const [src, dest] of Object.entries(eeoMap)) {
      const v = eeo[src];
      if (typeof v === "string" && v.trim()) payload[dest] = v;
    }
    for (const [key, value] of Object.entries(profile.answers ?? {})) {
      if (typeof value === "string" && value.trim()) payload[`answer:${key}`] = value;
    }
    return payload;
  }

  // .claude/worktrees/prepare-application-wiring/extension/src/stopConditions.ts
  var CAPTCHA_SELECTORS = [
    'iframe[src*="recaptcha"]',
    ".g-recaptcha",
    "[data-sitekey]",
    'iframe[src*="hcaptcha"]',
    ".h-captcha",
    "[data-hcaptcha]",
    "[data-hcaptcha-widget-id]"
  ];
  var MFA_SELECTORS = [
    'input[autocomplete="one-time-code"]',
    'input[name*="otp" i]',
    'input[id*="otp" i]',
    'input[name*="one-time" i]',
    'input[name*="verification-code" i]',
    'input[name*="verification_code" i]',
    'input[inputmode="numeric"][name*="code" i]'
  ];
  var LOGIN_SELECTORS = [
    'input[type="password"]',
    'form[action*="login" i]',
    'form[action*="signin" i]',
    'form[action*="sign-in" i]',
    '[data-testid*="login" i]',
    "#login-form",
    ".login-required"
  ];
  function anyMatch(root, selectors) {
    for (const sel of selectors) {
      try {
        if (root.querySelector(sel)) return true;
      } catch {
      }
    }
    return false;
  }
  function detectStopConditions(root) {
    const reasons = [];
    if (!root || typeof root.querySelector !== "function") return { reasons };
    if (anyMatch(root, CAPTCHA_SELECTORS)) reasons.push("captcha");
    if (anyMatch(root, MFA_SELECTORS)) reasons.push("mfa_otp");
    if (anyMatch(root, LOGIN_SELECTORS)) reasons.push("login_wall");
    return { reasons };
  }
  function describeStopReason(reason) {
    switch (reason) {
      case "captcha":
        return "a CAPTCHA challenge";
      case "mfa_otp":
        return "a verification-code (MFA) step";
      case "login_wall":
        return "a sign-in wall";
      default:
        return "a manual step";
    }
  }

  // .claude/worktrees/prepare-application-wiring/extension/src/nativeApply.ts
  function detectNativeApply(doc = document) {
    const found = [];
    if (!doc || typeof doc.querySelectorAll !== "function") return found;
    const signatures = [
      { provider: "greenhouse", patterns: [/my\s*greenhouse/i, /apply with greenhouse/i] },
      { provider: "linkedin", patterns: [/easy apply/i, /apply with linkedin/i] },
      { provider: "indeed", patterns: [/indeed apply/i, /apply with indeed/i] },
      { provider: "workday", patterns: [/autofill with resume/i, /use my last application/i] }
    ];
    const clickableSel = 'button, a[href], [role="button"], input[type="submit"], input[type="button"]';
    const ownUiSel = "#bkt-apply-root, #bkt-fit-panel, #bkt-native-apply";
    const controlText = (el) => {
      const own = el instanceof HTMLInputElement ? el.value : el.textContent ?? "";
      const aria = el.getAttribute("aria-label") ?? "";
      const title = el.getAttribute("title") ?? "";
      return `${own} ${aria} ${title}`.replace(/\s+/g, " ").trim();
    };
    const view = doc.defaultView ?? null;
    const isHidden = (el) => {
      try {
        if (el instanceof HTMLElement && el.hidden) return true;
        if (el instanceof HTMLInputElement && el.type === "hidden") return true;
        const cs = view?.getComputedStyle(el);
        return cs ? cs.display === "none" || cs.visibility === "hidden" : false;
      } catch {
        return false;
      }
    };
    let controls;
    try {
      controls = Array.from(doc.querySelectorAll(clickableSel));
    } catch {
      return found;
    }
    for (const { provider, patterns } of signatures) {
      for (const el of controls) {
        if (el.closest(ownUiSel)) continue;
        if (isHidden(el)) continue;
        const text = controlText(el);
        if (text && patterns.some((p) => p.test(text))) {
          found.push({ provider, label: text });
          break;
        }
      }
    }
    return found;
  }
  function renderNativeApplyNote(options) {
    const NOTE_ID = "bkt-native-apply";
    document.getElementById(NOTE_ID)?.remove();
    if (!options.length) return;
    const providerNames = {
      greenhouse: "Greenhouse",
      linkedin: "LinkedIn",
      indeed: "Indeed",
      workday: "Workday"
    };
    const note = document.createElement("div");
    note.id = NOTE_ID;
    note.setAttribute("data-bkt", "native-apply");
    note.setAttribute("role", "note");
    const title = document.createElement("div");
    title.setAttribute("data-bkt", "native-title");
    title.textContent = "Faster: native quick-apply available";
    note.appendChild(title);
    const ul = document.createElement("ul");
    for (const opt of options) {
      const li = document.createElement("li");
      li.setAttribute("data-provider", opt.provider);
      li.textContent = `\u201C${opt.label}\u201D \u2014 fills from your ${providerNames[opt.provider]} account`;
      ul.appendChild(li);
    }
    note.appendChild(ul);
    const hint = document.createElement("div");
    hint.setAttribute("data-bkt", "native-hint");
    hint.textContent = "Click it yourself to sign in, then review before submitting \u2014 we never click it for you.";
    note.appendChild(hint);
    document.body.appendChild(note);
  }

  // .claude/worktrees/prepare-application-wiring/extension/src/messages.ts
  var MSG = {
    /** SPA reader → background: the user's session (or null when signed out). */
    SESSION_PUSH: "BKT_SESSION_PUSH",
    /** ATS content → background: is the user signed in? */
    AUTH_STATUS: "BKT_AUTH_STATUS",
    /** ATS content → background: score this scraped JD via score-job-fit. */
    SCORE: "BKT_SCORE",
    /** ATS content → background: the contact profile for autofill. */
    PROFILE: "BKT_PROFILE",
    /** ATS content → background: the prepared-application payload for this page. */
    PREPARED: "BKT_PREPARED"
  };

  // .claude/worktrees/prepare-application-wiring/extension/src/content/index.ts
  var SIGN_IN_HINT = "Sign in at the BKT web app to score & autofill.";
  function send(msg) {
    try {
      return chrome.runtime.sendMessage(msg).catch(() => null);
    } catch {
      return Promise.resolve(null);
    }
  }
  function setStatus(text) {
    const el = document.getElementById("bkt-apply-status");
    if (el) el.textContent = text;
  }
  function scrapeJob(config) {
    const titleEl = config.jd.title ? document.querySelector(config.jd.title) : null;
    const containerEl = config.jd.container ? document.querySelector(config.jd.container) : null;
    const title = (titleEl?.textContent ?? document.title ?? "").replace(/\s+/g, " ").trim().slice(0, 300);
    const description = (containerEl?.textContent ?? document.body?.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 12e3);
    return { title, description, url: location.href, host: location.host };
  }
  function injectStyles() {
    if (document.getElementById("bkt-apply-styles")) return;
    const style = document.createElement("style");
    style.id = "bkt-apply-styles";
    style.textContent = `
#bkt-apply-root, #bkt-fit-panel {
  position: fixed !important; right: 16px !important; z-index: 2147483647 !important;
  box-sizing: border-box !important; background: #ffffff !important;
  border: 1px solid #e2e8f0 !important; border-radius: 12px !important;
  box-shadow: 0 8px 24px rgba(15,23,42,.18) !important; color: #0f172a !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
}
#bkt-apply-root { top: 16px !important; display: flex !important; align-items: center !important; gap: 8px !important; padding: 10px 12px !important; }
#bkt-fit-panel { top: 74px !important; width: 320px !important; max-height: 70vh !important; overflow: auto !important; padding: 12px 14px !important; font-size: 13px !important; line-height: 1.45 !important; }
#bkt-fit-panel ul { margin: 4px 0 8px !important; padding-left: 18px !important; }
#bkt-fit-panel [data-bkt="score"] { font-weight: 700 !important; font-size: 15px !important; }
#bkt-score-btn, #bkt-autofill-btn { cursor: pointer !important; border: 0 !important; border-radius: 8px !important; padding: 8px 10px !important; font-size: 13px !important; font-weight: 600 !important; color: #fff !important; white-space: nowrap !important; }
#bkt-score-btn { background: #2563eb !important; }
#bkt-autofill-btn { background: #0f172a !important; }
#bkt-apply-status { font-size: 12px !important; color: #475569 !important; max-width: 220px !important; }
#bkt-fit-panel [data-bkt="score"] { margin-bottom: 6px !important; line-height: 1.35 !important; }
#bkt-fit-panel [data-bkt="recommendation"] { margin: 4px 0 8px !important; color: #475569 !important; font-size: 12px !important; }
#bkt-fit-panel [data-bkt="matched"], #bkt-fit-panel [data-bkt="missing"] { margin-top: 8px !important; }
#bkt-fit-panel [data-bkt="matched"] > div:first-child, #bkt-fit-panel [data-bkt="missing"] > div:first-child { font-weight: 600 !important; font-size: 12px !important; margin-bottom: 2px !important; }
#bkt-apply-root { max-width: calc(100vw - 32px) !important; flex-wrap: wrap !important; }
#bkt-native-apply {
  position: fixed !important; bottom: 16px !important; right: 16px !important;
  z-index: 2147483647 !important; box-sizing: border-box !important;
  width: 320px !important; max-width: calc(100vw - 32px) !important;
  background: #f0f9ff !important; border: 1px solid #bae6fd !important; border-radius: 12px !important;
  box-shadow: 0 8px 24px rgba(15,23,42,.18) !important; color: #0f172a !important;
  padding: 10px 12px !important; font-size: 12px !important; line-height: 1.45 !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
}
#bkt-native-apply [data-bkt="native-title"] { font-weight: 700 !important; font-size: 13px !important; margin-bottom: 4px !important; }
#bkt-native-apply ul { margin: 4px 0 6px !important; padding-left: 16px !important; }
#bkt-native-apply [data-bkt="native-hint"] { color: #475569 !important; }
`;
    (document.head ?? document.documentElement).appendChild(style);
  }
  function renderInitialPanel() {
    document.getElementById("bkt-fit-panel")?.remove();
    const panel = document.createElement("div");
    panel.id = "bkt-fit-panel";
    panel.setAttribute("data-bkt", "fit-panel");
    panel.setAttribute("role", "complementary");
    const msg = document.createElement("div");
    msg.setAttribute("data-bkt", "score");
    msg.textContent = "Not scored yet \u2014 click \u201CGet Match Score\u201D.";
    panel.appendChild(msg);
    document.body.appendChild(panel);
  }
  async function onScore(config) {
    setStatus("Scoring this role\u2026");
    const res = await send({ type: MSG.SCORE, job: scrapeJob(config) });
    if (!res) {
      setStatus("Could not reach the extension background.");
      return;
    }
    if (res.ok) {
      renderMatchScorePanel(res.score);
      setStatus("Match score updated.");
    } else if (res.reason === "needs_login") {
      setStatus(SIGN_IN_HINT);
    } else {
      setStatus(`Scoring failed: ${res.message ?? "unknown error"}`);
    }
  }
  function stopConditionNote() {
    const { reasons } = detectStopConditions(document);
    if (!reasons.length) return "";
    const list = reasons.map(describeStopReason).join(", ");
    return ` This page also has ${list} \u2014 finish that step yourself.`;
  }
  function gatedNote(gated) {
    if (!gated.length) return "";
    return ` ${gated.length} sensitive field(s) need your review \u2014 fill those yourself.`;
  }
  async function runAutofill(config, payload, gated, source) {
    const report = await applyAutofill({ config, payload });
    const fileNote = report.skipped.some((s) => s.reason === "manual_required") ? " Attach your resume manually." : "";
    const label = source === "prepared" ? "Prepared autofill" : "Filled";
    setStatus(
      `${label}: ${report.filled.length} field(s). Review, then submit yourself.${fileNote}${gatedNote(gated)}${stopConditionNote()}`
    );
  }
  async function tryPreparedAutofill(config) {
    const res = await send({ type: MSG.PREPARED, job: { url: location.href } });
    if (!res || !res.ok) return false;
    if (res.status === "blocked") {
      setStatus(`This application is blocked from autofill \u2014 open it in the BKT app.${gatedNote(res.gated)}`);
      return true;
    }
    await runAutofill(config, res.payload, res.gated, "prepared");
    return true;
  }
  async function onAutofill(config) {
    setStatus("Looking for a prepared application\u2026");
    if (await tryPreparedAutofill(config)) return;
    setStatus("Fetching your profile\u2026");
    const res = await send({ type: MSG.PROFILE });
    if (!res) {
      setStatus("Could not reach the extension background.");
      return;
    }
    if (!res.ok) {
      setStatus(
        res.reason === "needs_login" ? SIGN_IN_HINT : res.reason === "no_profile" ? "No candidate profile found \u2014 add one in the BKT app." : `Autofill failed: ${res.message ?? "unknown error"}`
      );
      return;
    }
    await runAutofill(config, buildPayload(res.profile), [], "profile");
  }
  function buildControls(config) {
    if (document.getElementById("bkt-apply-root")) return;
    const root = document.createElement("div");
    root.id = "bkt-apply-root";
    root.setAttribute("data-bkt", "apply-root");
    const scoreBtn = document.createElement("button");
    scoreBtn.id = "bkt-score-btn";
    scoreBtn.type = "button";
    scoreBtn.textContent = "BKT: Get Match Score";
    scoreBtn.addEventListener("click", () => void onScore(config));
    const fillBtn = document.createElement("button");
    fillBtn.id = "bkt-autofill-btn";
    fillBtn.type = "button";
    fillBtn.textContent = "BKT: Autofill";
    fillBtn.addEventListener("click", () => void onAutofill(config));
    const status = document.createElement("div");
    status.id = "bkt-apply-status";
    status.setAttribute("data-bkt", "status");
    root.append(scoreBtn, fillBtn, status);
    document.body.appendChild(root);
  }
  async function init() {
    const config = resolveBoardConfig(location.host);
    if (!config) return;
    document.documentElement.setAttribute("data-bkt-apply", config.ats);
    injectStyles();
    renderInitialPanel();
    buildControls(config);
    renderNativeApplyNote(detectNativeApply(document));
    const status = await send({ type: MSG.AUTH_STATUS });
    document.documentElement.setAttribute(
      "data-bkt-auth",
      status ? status.signedIn ? "signed-in" : "signed-out" : "unavailable"
    );
    setStatus(status?.signedIn ? "Signed in \u2014 ready." : SIGN_IN_HINT);
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => void init());
  } else {
    void init();
  }
})();
